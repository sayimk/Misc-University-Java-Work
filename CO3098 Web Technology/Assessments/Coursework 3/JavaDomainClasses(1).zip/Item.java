package uk.ac.le.cs.CO3098.cw3.domain;

public class Item extends BookmarkEntity{

	public Item(String path) {
		super(path);
		// TODO Auto-generated constructor stub
	}

}
